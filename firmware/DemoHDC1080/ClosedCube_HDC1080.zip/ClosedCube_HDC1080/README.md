ClosedCube Arduino Library for
ClosedCube HDC1080 Low Power High Accuracy Digital I2C Humidity and Temperature Sensor Breakout
=================================================================

This is breakout board for [Texas Instruments HDC1080](http://www.ti.com/product/HDC1080) Low Power High Accuracy Digital Humidity Sensor with Temperature Sensor 


[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)



---
### Where to Buy?

<a href="https://www.amazon.co.uk/ClosedCube-Accuracy-Humidity-Temperature-Breakout/dp/B01GBOGNFE">
<img src="https://images-na.ssl-images-amazon.com/images/G/01/SellerCentral/legal/amazon-logo_black.png" width="145" height="70"/></a> <a href="https://www.amazon.co.uk/ClosedCube-Accuracy-Humidity-Temperature-Breakout/dp/B01GBOGNFE">UK</a>

[![](http://images.closedcube.uk/logo/github/ebay.gif)](http://www.ebay.co.uk/itm/182129971333)(UK Store)

<a href="https://www.tindie.com/stores/closedcube/?ref=offsite_badges&utm_source=sellers_closedcube&utm_medium=badges&utm_campaign=badge_medium"><img src="https://d2ss6ovg47m0r5.cloudfront.net/badges/tindie-mediums.png" alt="I sell on Tindie" width="150" height="78"></a>

